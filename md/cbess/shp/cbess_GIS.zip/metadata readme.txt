CBESS 
Chesapeake Bay Earth Science Study
-------------------------------------------------------------------
Surface Sediment DIstribution of the Chesapeake Bay in Maryland


Metadata addendum:

The accompanying dxf files have been reprojected from NAD 1927 to NAD 1983 Geographic coordinates using ESRI's ArcToolbox 8.3.

This reprojection was performed on the shoreline (SHORELINE.DXF), surface sample (SURFACE_SAMPLES.DXF) and surface sediment ditribution (*.DXF)  files.

For complete metadata on the shoreline.dxf data please see http://www.mgs.md.gov/coastal/vmap/SLMetadata.html.